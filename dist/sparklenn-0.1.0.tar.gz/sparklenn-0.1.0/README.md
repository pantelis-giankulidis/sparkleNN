### Sparkle NN ###
Install the library with `poetry add sparklenn` for poetry, or `pip install sparklenn`.\
Import in your project with `from sparklenn import *`